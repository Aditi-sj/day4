package com.stackroute.springdatajpamysql.service;


import com.stackroute.springdatajpamysql.entity.Product;
import com.stackroute.springdatajpamysql.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

//Implement ProductService here
@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepo productRepo;


    public ProductServiceImpl(ProductRepo productRepo) {
        this.productRepo = productRepo;
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> list= productRepo.findAll();
        return list;
    }

    @Override
    public List<Product> getAllProductsHavingPriceLessThan(double price) {
//        List<Product> list=productRepo.findAll();
//        List<Product>newList=list.stream().filter(product -> product.getPrice()<price).collect(Collectors.toList());
        return productRepo.findProductsLessThanPrice(price);
    }

    @Override
    public Product getProductById(Long id) {
        return productRepo.findById(id).get();
    }

    @Override
    public Product saveProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public Product updateProduct(Product product,Long id) {
        Product product1=productRepo.findById(id).get();
        product1.setName(product.getName());
        product1.setPrice(product.getPrice());
        return productRepo.save(product1);
    }

    @Override
    public String deleteProduct(Long id) {
        return "Product deleted successfully";
    }
    //Override all the methods here
}
