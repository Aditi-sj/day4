package com.stackroute.springdatajpamysql.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Table(name="products_day4")
public class Product {
    //Add Product entity fields, constructors and getters/setters here
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private double price;

}
