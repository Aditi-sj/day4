package com.stackroute.springdatajpamysql.service;

import com.stackroute.springdatajpamysql.entity.Product;
import org.springframework.stereotype.Service;

import java.util.List;

//Create service interface here
@Service
public interface ProductService {
    //Add abstract methods here
    List<Product> getAllProducts();
    List<Product> getAllProductsHavingPriceLessThan(double price);
    Product getProductById(Long id);
    Product saveProduct(Product product);
    Product updateProduct(Product product,Long id);
    String deleteProduct(Long id);
}
